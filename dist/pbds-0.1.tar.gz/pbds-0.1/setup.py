from setuptools import setup

setup(
    name='pbds',
    version="0.1",
    description='first commit',
    author='Manthan Solanki',
    packages=['pbds'],
    install_requires=[]
)
